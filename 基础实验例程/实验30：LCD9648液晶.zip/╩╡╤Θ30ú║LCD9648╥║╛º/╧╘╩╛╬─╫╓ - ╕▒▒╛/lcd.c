#include "lcd9648.h"




void Delay10ms(unsigned int c)   //��� 0us
{
    unsigned char a,b;
    for(;c>0;c--)
        for(b=38;b>0;b--)
            for(a=130;a>0;a--);
}





void main()
{
	unsigned char i;
	LCD9648_Init();
	LCD9648_Clear();
	LCD9648_Write16CnCHAR(15,0,"���пƼ�");
	while(1)
	{
		for(i = 0; i < 5; i+=2)
		{
			LCD9648_Write16CnCHAR(15,i,"���пƼ�");
			Delay10ms(100);
			LCD9648_Clear();	
		}
	}	
}